# vMix Remote Android (source project)

Starter project Android Studio untuk mengontrol vMix melalui HTTP API.

## Fitur yang sudah disiapkan
- Koneksi ke alamat IP vMix PC (port default 8088)
- Membaca XML API dan daftar input
- Memilih input ke Preview
- Start/Stop Streaming dan Recording
- Cut, Fade, Merge, Wipe, Fade to Black, Quick Play
- Overlay 1–4 dan Overlay 1 Off
- Kontrol pan/tilt/zoom digital pada input terpilih menggunakan SetPanX, SetPanY, SetZoom; simpan/update posisi virtual
- Kolom URL monitor Program dan Preview (URL stream harus disediakan/diaktifkan sendiri)

## Cara membuat APK
1. Install Android Studio pada PC.
2. Ekstrak ZIP, lalu Android Studio > Open > pilih folder `VMixRemote`.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Pengaturan vMix
1. Di vMix PC buka Settings > Web Controller / Web.
2. Aktifkan HTTP Web API dan pastikan port (umumnya 8088).
3. Pastikan PC dan HP satu jaringan Wi-Fi/LAN.
4. Izinkan koneksi aplikasi melalui Windows Firewall pada jaringan Private.
5. Isi IP PC, contoh `192.168.1.10:8088`, lalu tekan HUBUNGKAN.

## Catatan penting
- Ini adalah proyek sumber Android Studio, bukan APK yang sudah dikompilasi. Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle, jadi APK biner tidak dapat dibangun di sini.
- Fungsi shortcut tertentu dapat berbeda menurut edisi/versi vMix. Uji dahulu sebelum siaran.
- Monitor video tidak otomatis mengambil gambar dari XML API. Isi URL output/stream Program dan Preview yang valid. XML API sendiri memberi status dan metadata, bukan frame video.
- Kontrol Virtual PTZ di proyek ini memakai SetPanX, SetPanY, SetZoom pada input yang dipilih. Tombol simpan posisi mengirim PTZUpdateVirtualInput; hasilnya bergantung pada jenis input dan dukungan vMix.
- Aplikasi ini menggunakan HTTP tanpa autentikasi pada jaringan lokal. Jangan membuka port API vMix langsung ke internet.
