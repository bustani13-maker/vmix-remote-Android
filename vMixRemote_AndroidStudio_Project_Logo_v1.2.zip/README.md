# vMix Remote Android 1.2

Proyek Android Studio untuk build APK vMix Remote.

## Perbaikan ikon 1.2
- Menggunakan ikon PNG density-specific pada mipmap-mdpi, hdpi, xhdpi, xxhdpi, dan xxxhdpi.
- Menghapus adaptive icon override agar launcher memakai ikon PNG yang sudah disertakan.
- application label: vMix Remote.
- versionCode 3 / versionName 1.2.

## Build
Gunakan GitHub Actions workflow yang sudah ada di repository. Ekstrak ZIP ini dan jalankan Gradle `assembleDebug`. Hasil APK: `app/build/outputs/apk/debug/app-debug.apk`.

Setelah memasang build baru, bila ikon masih lama: uninstall aplikasi vMix Remote lama, pasang APK versi 1.2, lalu restart launcher/HP.
