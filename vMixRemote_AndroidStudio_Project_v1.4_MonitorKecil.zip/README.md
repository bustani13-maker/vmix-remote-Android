# vMix Remote Android 1.4

Pembaruan dari versi 1.3:
- Ukuran monitor PROGRAM dan PREVIEW diperkecil sedikit dan tetap berdampingan.
- Lebar area monitor dibatasi agar tampilan lebih ringkas pada layar besar.
- Fitur kontrol, koneksi API, dan Virtual PTZ dari versi 1.3 dipertahankan.

Catatan: kolom URL stream masih merupakan cara manual untuk menampilkan video. Versi ini belum menambahkan penerima NDI native; pengaktifan NDI pada vMix saja tidak otomatis membuat video tampil di aplikasi.

Build melalui GitHub Actions seperti proyek sebelumnya.
