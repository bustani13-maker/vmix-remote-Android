package com.example.vmixremote;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private WebView web;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile String baseUrl = "http://192.168.1.100:8088";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "VMix");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private String request(String path) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(baseUrl + path).openConnection();
        c.setConnectTimeout(1800);
        c.setReadTimeout(1800);
        c.setRequestMethod("GET");
        try (InputStream in = c.getInputStream();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return out.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    public class Bridge {
        @JavascriptInterface public void setHost(String host) {
            if (host == null) return;
            String h = host.trim();
            if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://" + h;
            if (h.matches("^https?://[a-zA-Z0-9.:-]+$")) baseUrl = h;
        }

        // Network polling runs off the WebView/UI thread so typing and tapping stay responsive.
        @JavascriptInterface public void getStateAsync() {
            executor.execute(() -> {
                String result;
                try { result = request("/api/"); }
                catch (Exception e) { result = ""; }
                final String payload = JSONObject.quote(result);
                runOnUiThread(() -> {
                    if (web != null) web.evaluateJavascript("window.onVmixState(" + payload + ");", null);
                });
            });
        }

        @JavascriptInterface public void command(String fn, String input, String value, int duration, int index) {
            executor.execute(() -> {
                try {
                    String q = "/api/?Function=" + enc(fn);
                    if (input != null && !input.isEmpty()) q += "&Input=" + enc(input);
                    if (value != null && !value.isEmpty()) q += "&Value=" + enc(value);
                    if (duration > 0) q += "&Duration=" + duration;
                    if (index >= 0) q += "&SelectedIndex=" + index;
                    request(q);
                } catch (Exception ignored) {}
            });
        }

        private String enc(String s) {
            try { return URLEncoder.encode(s, "UTF-8"); }
            catch (Exception e) { return s; }
        }
    }

    @Override protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("VMix");
            web.destroy();
            web = null;
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
