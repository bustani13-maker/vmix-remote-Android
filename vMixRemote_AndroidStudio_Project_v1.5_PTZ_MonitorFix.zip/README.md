# vMix Remote Android 1.5

Pembaruan dari 1.4:
- Menambahkan dropdown pemilihan input vMix untuk Virtual PTZ.
- Daftar input otomatis diperbarui dari API vMix; tombol input juga memilih input untuk PTZ dan Preview.
- Menambahkan tombol kirim input terpilih ke Overlay 1–4.
- Menambahkan Reset PTZ (Pan X/Y kembali 0 dan Zoom kembali 1).
- Memperbaiki monitor agar elemen video tidak dihapus setiap polling API.
- Monitor URL mendukung stream HTTP/HTTPS yang dapat diputar Android WebView.

PENTING: versi ini TIDAK menyertakan decoder NDI native. NDI On di vMix tidak berarti WebView dapat menerima NDI. Untuk menampilkan External Output 1/2 NDI secara langsung di monitor APK, perlu integrasi NDI SDK Android dan proses native decoding; SDK/dependency tersebut tidak disertakan dalam ZIP ini. Kolom URL monitor hanya menerima URL stream yang browser-compatible (contoh MP4/MJPEG, dan format lain yang didukung perangkat).

Virtual PTZ memakai fungsi vMix SetPanX, SetPanY, SetZoom pada input terpilih. Kontrol ini mengubah framing input, bukan posisi overlay channel. Tombol Overlay menampilkan input terpilih pada overlay 1–4.

Build melalui GitHub Actions seperti versi sebelumnya.
