# vMix Remote Android 1.1 — Logo update

This is an updated Android Studio source project. It uses the user's supplied 3x3 blue/green/orange logo as the Android launcher icon and in-app header logo. The Android version is incremented to 1.1 (versionCode 2) for installing as an update over version 1.0.

## Build with GitHub Actions
1. Replace the old project ZIP in the GitHub repository with this ZIP, keeping only one root-level `.zip` file because the workflow extracts the first root ZIP it finds.
2. Run the existing `Build vMix Remote APK` workflow.
3. Download artifact `vMixRemote-APK`, extract it, and install `app-debug.apk`.

## Build notes
- Android application ID: `com.example.vmixremote`
- Launcher icon: supplied user logo
- In-app header: supplied user logo
- This remains an early prototype. Check vMix API command support and configure Program/Preview stream URLs before relying on it for a live production.
