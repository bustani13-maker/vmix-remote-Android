# vMix Remote Android 1.3

## Perbaikan responsivitas
- Permintaan status XML API vMix dijalankan di background thread, bukan thread tampilan WebView.
- Input alamat IP, keyboard, tombol, dan navigasi tidak lagi menunggu respons jaringan saat polling.
- Polling status dibuat 1,8 detik dan tidak menumpuk jika permintaan sebelumnya belum selesai.
- Timeout koneksi dipersingkat menjadi 1,8 detik agar aplikasi cepat memberi status gagal konek.
- Ikon/logo versi 1.2 tetap dipertahankan.

## Build APK
Gunakan GitHub Actions workflow yang sudah ada di repository. Upload ZIP ini dan jalankan workflow `Build vMix Remote APK`. Hasilnya `app-debug.apk`.

## Instalasi
Versi ini memakai applicationId yang sama dan versionCode lebih tinggi (4), sehingga dapat dipasang sebagai pembaruan di atas versi 1.2 jika APK ditandatangani dengan kunci build yang sama. Jika Android menolak karena tanda tangan berbeda, uninstall versi lama lalu instal APK baru.
